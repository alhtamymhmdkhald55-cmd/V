# City Crime — Open World Starter (Godot 4)

This is a small, original open-world city prototype, not a copy of GTA 6. It gives you a foundation to expand into your own third-person action/driving game.

## Requirements
- Godot Engine 4.2 or newer (the standard edition is enough).
- For Android export, install the Android build templates and configure the Android SDK/JDK in Godot's Editor Settings.

## Run
1. Extract the ZIP.
2. Open Godot Project Manager.
3. Choose **Import** and select `project.godot`.
4. Open the project and press **F6** or **F5**.

## Controls
- WASD / arrow keys: move
- Mouse: look around
- Space: jump
- Shift: sprint
- Escape: release mouse; click the game window to capture it again

## What's included
- Third-person character controller with gravity, jumping, sprinting, and mouse look.
- Procedurally generated block-city with simple building collisions and a road grid.
- Basic HUD and environment lighting.

## Important limitations
This is a starter project, not a full commercial game. It does not yet include vehicles, missions, NPC AI, combat, police, save/load, audio, detailed interiors, or production assets. Those systems need to be developed and tested separately. The buildings are intentionally simple placeholders.

## Suggested next milestones
1. Add a vehicle scene with enter/exit interaction and arcade driving.
2. Add traffic and pedestrian AI with navigation.
3. Add mission triggers, objectives, and dialogue.
4. Add inventory, shops, and save/load.
5. Replace placeholder geometry with original models, textures, animation, and sound.
6. Optimize world streaming and test on the target Android devices.

Use original names, characters, maps, art, music, and story. Do not redistribute GTA assets or other copyrighted game files.
