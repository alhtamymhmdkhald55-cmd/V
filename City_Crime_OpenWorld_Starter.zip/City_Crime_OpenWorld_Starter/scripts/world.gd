extends Node3D

@export var blocks_each_side: int = 7
@export var block_spacing: float = 16.0
@export var road_width: float = 7.0

func _ready() -> void:
    randomize()
    _build_city()

func _build_city() -> void:
    var building_materials: Array[StandardMaterial3D] = []
    for color in [
        Color(0.55, 0.58, 0.62), Color(0.72, 0.62, 0.48),
        Color(0.36, 0.43, 0.5), Color(0.65, 0.68, 0.64)
    ]:
        var material := StandardMaterial3D.new()
        material.albedo_color = color
        building_materials.append(material)

    for x in range(-blocks_each_side, blocks_each_side + 1):
        for z in range(-blocks_each_side, blocks_each_side + 1):
            # Leave the spawn area open.
            if abs(x) <= 1 and abs(z) <= 1:
                continue
            var height := randf_range(5.0, 24.0)
            var width := randf_range(5.0, 8.0)
            var depth := randf_range(5.0, 8.0)
            var building := StaticBody3D.new()
            building.position = Vector3(x * block_spacing, height / 2.0, z * block_spacing)

            var mesh_instance := MeshInstance3D.new()
            var box := BoxMesh.new()
            box.size = Vector3(width, height, depth)
            mesh_instance.mesh = box
            mesh_instance.material_override = building_materials[randi() % building_materials.size()]
            building.add_child(mesh_instance)

            var collision := CollisionShape3D.new()
            var shape := BoxShape3D.new()
            shape.size = box.size
            collision.shape = shape
            building.add_child(collision)
            add_child(building)

    # Broad dark road strips make a simple grid.
    var road_material := StandardMaterial3D.new()
    road_material.albedo_color = Color(0.12, 0.13, 0.15)
    for i in range(-blocks_each_side, blocks_each_side + 1):
        var road_x := MeshInstance3D.new()
        var road_mesh_x := BoxMesh.new()
        road_mesh_x.size = Vector3(road_width, 0.04, (blocks_each_side * 2 + 1) * block_spacing)
        road_x.mesh = road_mesh_x
        road_x.position = Vector3(i * block_spacing, 0.02, 0)
        road_x.material_override = road_material
        add_child(road_x)

        var road_z := MeshInstance3D.new()
        var road_mesh_z := BoxMesh.new()
        road_mesh_z.size = Vector3((blocks_each_side * 2 + 1) * block_spacing, 0.04, road_width)
        road_z.mesh = road_mesh_z
        road_z.position = Vector3(0, 0.021, i * block_spacing)
        road_z.material_override = road_material
        add_child(road_z)
